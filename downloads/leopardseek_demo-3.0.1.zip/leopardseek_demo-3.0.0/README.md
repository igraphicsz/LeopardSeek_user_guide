# 自动交易回测工具
## 简介
  这是一个整合自动化回测, 模拟盘与实盘交易的工具，用户可以通过配置各种参数来进行回测以及模拟交易与实盘交易。
# 配置文件
## 全局配置文件示例
```
全局配置：config.json
{
  "license": "123456", # 准入许可，联系相关人获取
  "strategy": "macd",  # 策略名称(策略文件名)

  # 回测功能需要设置回测开始于结束时间
  "begin": "10/7/2025",
  "end": "11/7/2025",

  # 模拟盘与实盘交易功能需要设置交易账号与密码
  "account": "123456",
  "password": "123456"
}
```
## 策略配置文件示例
```
策略配置：config下的yaml
{
  NAME: 'macd'      # 策略名称
  MODULE: 'macd'    # 与策略名称一致
  CLASS: 'MACD'     # 策略文件的类名
  INTERVAL: '1min'  # 回测间隔周期
  PARAMETERS:       # 策略参数
    macd_fast: 12
    macd_slow: 26
    macd_smoothing: 9

  WATCHLIST: ['ao2605', 'rb2605', 'jm2605', 'm2605']  # 回测合约列表
}
```
# 策略文件
策略在strategies文件夹下编写，可参考示例策略代码

# 回测, 模拟盘或实盘交易

## 安装依赖
请使用 Python 3.11 的虚拟环境安装依赖并运行 LeopardSeek。
```bash
pip install http://www.popper-fintech.com/ls/leopardseek_main-1.0.0.tar.gz
```

## 执行
```bash
执行 Start_backtest.py  Main方法(回测)
执行 Start_virtual_trade.py  Main方法(模拟盘交易)
执行 Start_live_trade.py  Main方法(实盘交易)
```
