import pandas as pd
import numpy as np
from talib import EMA
from logging import Logger

from autotrader.strategy import Strategy
from autotrader.brokers.lzdc_broker import Broker
from autotrader.comms.Enum import Direction, Offset, OrderType, CandlesPeriod, PosDirection
from autotrader.brokers.lzdc_order import Order

class MACD(Strategy):
    def __init__(
        self, parameters: dict, instrument: str, broker: Broker, logger: Logger, *args, **kwargs
    ) -> None:
        self.name = "macd"
        self.instrument = instrument
        self.broker = broker
        self.parameters = parameters
        self.logger = logger

        # 从self.parameters中获取计算需要的参数
        self.fast_period = self.parameters.get('macd_fast', 12)
        self.slow_period = self.parameters.get('macd_slow', 26)
        self.macd_period = self.parameters.get('macd_smoothing', 9)

        # 初始化策略运行需要属性
        self.previous_diff = None
        self.previous_macd = None

    def generate_features(self, dt):
        """
        生成基于MACD的趋势信号
        """
        # 获取价格数据, 本次调用获取了本产品1000根1分钟级的k线数据
        df  = self.broker.get_candles(self.instrument, granularity=CandlesPeriod.MIN_1, count=1000, end_time=dt)
        close = df['close']

        ema20 = EMA(close, self.fast_period)
        ema80 = EMA(close, self.slow_period)
        
        DIFF = ema20 - ema80
        DEA = EMA(DIFF, self.macd_period)
        MACD = (DIFF - DEA)

        latest_fix_diff = DIFF[-2]
        latest_fix_macd = MACD[-2]
   
        signal = 0
        if latest_fix_diff > 0 and latest_fix_macd > 0:
            signal = 1
        elif latest_fix_diff < 0 and latest_fix_macd < 0:
            signal = -1

        self.previous_diff = latest_fix_diff
        self.previous_macd = latest_fix_macd

        return signal


    def generate_signal(self, dt) -> int:
        """
        生成交易信号
        """
        # 获取持仓信息
        holding_direction = 0
        holding_size = 0
        position_dicts = self.broker.get_positions(self.instrument)
        if position_dicts:
            for position_dict in position_dicts:
                if position_dict["direction"] == PosDirection.Long:  # 多头
                    holding_direction = 1
                    holding_size = position_dict['position']

                elif position_dict["direction"] == PosDirection.Short:  # 空头
                    holding_direction = -1
                    holding_size = position_dict['position']

        # 通过generate_features生成趋势信号
        signal = self.generate_features(dt)

        # 获取最新价格
        df  = self.broker.get_candles(self.instrument, granularity=CandlesPeriod.MIN_1, count=1000, end_time=dt)
        close = df['close']
        current_price = close.iloc[-1]

        orders = []

        # 多头持仓情况
        if holding_direction == 1:
            # 若趋势方向不为多头，平多仓：
            if signal != 1:
                close_long_tdposition = Order(
                        instrument=self.instrument,
                        direction=Direction.Short,
                        offset=Offset.Close,
                        order_type=OrderType.Market,
                        price=current_price,
                        size=holding_size
                    )
                orders.append(close_long_tdposition)
            
            if signal == -1:
                orders.append(Order(
                instrument=self.instrument,
                direction=Direction.Short,
                offset=Offset.Open,
                order_type=OrderType.Market,
                price=current_price,
                size=1
            ))


        # 空头持仓情况
        elif holding_direction == -1:
            # 若趋势方向不为空头，平空仓：
            if signal != -1:
                close_short_tdposition = Order(
                        instrument=self.instrument,
                        direction=Direction.Long,
                        offset=Offset.Close,
                        order_type=OrderType.Market,
                        price=current_price,
                        size=holding_size
                    )
                orders.append(close_short_tdposition)


            # 若有趋势为多，开多仓
            if signal == 1:
                orders.append(Order(
                instrument=self.instrument,
                direction=Direction.Long,
                offset=Offset.Open,
                order_type=OrderType.Market,
                price=current_price,
                size=1
            ))

        # 若有趋势方向
        else:
            if signal == 1:
                self.logger.info('开多仓')
                orders.append(Order(
                instrument=self.instrument,
                direction=Direction.Long,
                offset=Offset.Open,
                order_type=OrderType.Market,
                price=current_price,
                size=1
            ))
            elif signal == -1:
                self.logger.info('开空仓')
                orders.append(Order(
                instrument=self.instrument,
                direction=Direction.Short,
                offset=Offset.Open,
                order_type=OrderType.Market,
                price=current_price,
                size=1
            ))


        return orders

